#!/usr/bin/env bash
#
# setup.sh
#
# This script will:
#   1. Create a sudo user "ross" and set its password (also sets root password).
#   2. Disable systemd socket for ssh (if enabled) and configure ssh to:
#      - Use port 6066
#      - Add your hardcoded public key
#      - Disable password authentication
#      - Disallow root login
#   3. Test SSH configuration with `sshd -t`. Revert on failure.
#   4. Install Docker via the official convenience script, plus Git/Vim/Tmux.
#      Then add "ross" to the docker group.
#   5. Copy local .tmux.conf, .vimrc, and .vimrc.plug to /home/ross (if present).
#   6. Install Tmux Plugin Manager (TPM) and Vim-Plug for user "ross."
#   7. Provide final instructions for Tmux and Vim plugin setup.
#

set -e  # Exit immediately on any error

#######################################
# 1. Ensure the script is run as root
#######################################
if [[ $EUID -ne 0 ]]; then
  echo "Please run as root (or use sudo)."
  exit 1
fi

#######################################
# 2. Prompt for password
#######################################
read -s -p "Enter password for user 'ross' (and root): " ROSSPASS
echo
read -s -p "Confirm password: " ROSSPASS_CONFIRM
echo

if [[ "$ROSSPASS" != "$ROSSPASS_CONFIRM" ]]; then
  echo "Passwords do not match. Exiting."
  exit 1
fi

#######################################
# 3. Create user 'ross' if it doesn't exist
#######################################
if ! id -u ross &>/dev/null; then
  echo "Creating user 'ross'..."
  adduser --gecos "" --disabled-password ross
fi

# Set password for 'ross'
echo "ross:$ROSSPASS" | chpasswd

# Add ross to the sudo group
usermod -aG sudo ross

# Set the same password for root
echo "root:$ROSSPASS" | chpasswd

#######################################
# 4. SSH Configuration
#######################################
echo "Configuring SSH..."

SSH_CONFIG="/etc/ssh/sshd_config"
TIMESTAMP="$(date +%F-%T)"
SSH_BACKUP="${SSH_CONFIG}.bak.${TIMESTAMP}"

# 4.1 Disable systemd socket-based activation (if enabled) in favor of ssh.service
if systemctl is-enabled ssh.socket &>/dev/null; then
  echo "Disabling socket-based SSH..."
  systemctl disable --now ssh.socket
  systemctl enable --now ssh
fi

# 4.2 Backup the original sshd_config
cp "$SSH_CONFIG" "$SSH_BACKUP"
echo "Backed up $SSH_CONFIG to $SSH_BACKUP"

# 4.3 Modify SSH settings in sshd_config

# Change Port to 6066
# If 'Port 22' is present, replace it; otherwise ensure "Port 6066" is added.
if grep -Eq "^[#]*\s*Port\s+22" "$SSH_CONFIG"; then
  sed -i 's|^[#]*\s*Port\s\+22|Port 6066|g' "$SSH_CONFIG"
else
  if grep -Eq "^[#]*\s*Port\s+" "$SSH_CONFIG"; then
    sed -i 's|^[#]*\s*Port\s\+.*|Port 6066|g' "$SSH_CONFIG"
  else
    echo "Port 6066" >> "$SSH_CONFIG"
  fi
fi

# Disable password authentication
sed -i 's/^[#]*\s*PasswordAuthentication\s\+yes/PasswordAuthentication no/g' "$SSH_CONFIG"
if ! grep -q "^PasswordAuthentication no" "$SSH_CONFIG"; then
  echo "PasswordAuthentication no" >> "$SSH_CONFIG"
fi

# Disable root login
sed -i 's/^[#]*\s*PermitRootLogin\s\+.*/PermitRootLogin no/g' "$SSH_CONFIG"
if ! grep -q "^PermitRootLogin no" "$SSH_CONFIG"; then
  echo "PermitRootLogin no" >> "$SSH_CONFIG"
fi

# Enable pubkey authentication
sed -i 's/^[#]*\s*PubkeyAuthentication\s\+.*/PubkeyAuthentication yes/g' "$SSH_CONFIG"
if ! grep -q "^PubkeyAuthentication yes" "$SSH_CONFIG"; then
  echo "PubkeyAuthentication yes" >> "$SSH_CONFIG"
fi

# 4.4 Add the public key for user ross
echo "Adding public key to /home/ross/.ssh/authorized_keys..."
mkdir -p /home/ross/.ssh
chmod 700 /home/ross/.ssh
cat << 'EOF' >> /home/ross/.ssh/authorized_keys
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDexoMdWMvwrzTbAzkpwzbvtnWuvpytsPtG10iBwORL0
EOF
chmod 600 /home/ross/.ssh/authorized_keys
chown -R ross:ross /home/ross/.ssh

#######################################
# 5. Test new SSH configuration
#######################################
echo "Testing new SSH configuration with 'sshd -t'..."
if ! sshd -t; then
  echo "SSH configuration test FAILED. Reverting to backup."
  mv "$SSH_BACKUP" "$SSH_CONFIG"
  exit 1
fi

echo "SSH configuration is valid. Removing backup..."
rm -f "$SSH_BACKUP"

# 5.1 Restart SSH
systemctl restart ssh
echo "SSH restarted successfully with the new configuration."

#######################################
# 6. Install Docker + dependencies
#######################################
echo "Installing Docker, Git, Vim, Tmux..."

apt-get update -y
apt-get install -y curl git vim tmux

curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Add 'ross' to the docker group
usermod -aG docker ross

rm -f get-docker.sh
echo "Docker installation complete."

#######################################
# 7. Copy config files (.tmux.conf, .vimrc, .vimrc.plug)
#    to /home/ross (if present)
#######################################
echo "Installing config files for 'ross'..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# .tmux.conf
if [[ -f "$SCRIPT_DIR/tmux.conf" ]]; then
  cp "$SCRIPT_DIR/tmux.conf" /home/ross/.tmux.conf
  chown ross:ross /home/ross/.tmux.conf
  echo "Copied tmux.conf to /home/ross/.tmux.conf"
else
  echo "Warning: tmux.conf not found in the current directory."
fi

# .vimrc
if [[ -f "$SCRIPT_DIR/vimrc" ]]; then
  cp "$SCRIPT_DIR/vimrc" /home/ross/.vimrc
  chown ross:ross /home/ross/.vimrc
  echo "Copied vimrc to /home/ross/.vimrc"
else
  echo "Warning: vimrc not found in the current directory."
fi

# .vimrc.plug (optional)
if [[ -f "$SCRIPT_DIR/.vimrc.plug" ]]; then
  cp "$SCRIPT_DIR/.vimrc.plug" /home/ross/.vimrc.plug
  chown ross:ross /home/ross/.vimrc.plug
  echo "Copied .vimrc.plug to /home/ross/.vimrc.plug"
else
  echo "Warning: .vimrc.plug not found in the current directory."
fi

#######################################
# 8. Install Tmux Plugin Manager (TPM) & Vim-Plug for user 'ross'
#######################################
echo "Installing Tmux Plugin Manager and Vim-Plug..."

# TPM (Tmux Plugin Manager)
sudo -u ross git clone https://github.com/tmux-plugins/tpm /home/ross/.tmux/plugins/tpm || true

# Vim-Plug
sudo -u ross bash -c "curl -fLo /home/ross/.vim/autoload/plug.vim --create-dirs \
    https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim" || true

#######################################
# 9. Final instructions
#######################################
echo "-----------------------------------------------"
echo "Setup complete!"
echo
echo " - User 'ross' has sudo privileges."
echo " - SSH is on port 6066, root login/password auth disabled."
echo " - Docker is installed, and 'ross' is in the docker group."
echo " - .tmux.conf, .vimrc, and optional .vimrc.plug are in /home/ross."
echo " - Tmux Plugin Manager (TPM) and Vim-Plug have been installed."
echo
echo "Next steps for 'ross':"
echo "1) Switch to user 'ross':  sudo su - ross"
echo "2) In Vim, install or update plugins:"
echo "   vim"
echo "   :PlugUpdate"
echo
echo "3) In Tmux, install plugins:"
echo "   tmux"
echo "   (Press Ctrl + a + I to install plugins.)"
echo
echo "4) To reload tmux.conf, press Ctrl + a + r or run:"
echo "   tmux source ~/.tmux.conf"
echo "-----------------------------------------------"
